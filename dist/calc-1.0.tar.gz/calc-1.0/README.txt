Description
===========

An example Calculator project.